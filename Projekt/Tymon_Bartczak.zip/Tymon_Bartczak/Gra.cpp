#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <ctime>

#include "Talia.h"
#include "Karta.h"
#include "Gra.h"

using namespace std;

Gra::Gra(){
    gracz1=0;
    gracz2=0;
    Talia T1;
    Talia T2;

};

void Gra::setup(){
  srand(time(NULL));
  char wybor;
  cout << "Czy chcesz stworzyc nowa talie (n) czy wczytac ja z pliku (w)? ";
  cin >> wybor;
  Talia mojaTalia;
    if (wybor == 'n' || wybor == 'N') {
        mojaTalia = Talia(52, true);
        mojaTalia.tasuj();
        char czyZapisac;
        cout << "Czy chcesz zapisac te potasowana talie do pliku txt? (t/n): ";
        cin >> czyZapisac;
        if (czyZapisac == 't' || czyZapisac == 'T') {
            string nazwaPliku;
            cout << "Podaj nazwe pliku (np. talia.txt): ";
            cin >> nazwaPliku;
            mojaTalia.zapiszDoPliku(nazwaPliku);

        }
    } else {
        string nazwaPliku;
        cout << "Podaj nazwe pliku tekstowego do wczytania: ";
        cin >> nazwaPliku;
        mojaTalia.wczytajZPliku(nazwaPliku);
    }
    vector<Karta> taliaKart;
    for (size_t i = 0; i < taliaKart.size()/2; i++) {
        Karta k = mojaTalia.pobierzKarte(i);
        T1.polozNaWierzch(k);
        cout << k.nazwaKarty() << endl;
    }
    cout<<endl;
    
    for (size_t i = taliaKart.size()/2; i < taliaKart.size(); i++) {
         Karta k = mojaTalia.pobierzKarte(i);
        T2.polozNaWierzch(k);
        cout << k.nazwaKarty() << endl;
    }
    
};   //pyta o utworzenie/wczytanie talii -> rozdziela talie na pół (robi 2 stosy)

void Gra::rozgrywka(){
vector<Karta> reka;
for(int i=0;i<=26;i++){
  reka.push_back(T1.dobierzZWierzchu());
  reka.push_back(T2.dobierzZWierzchu());
  if (reka[0].getWartosc()>reka[1].getWartosc()){
      if(reka[0].getKolor()==reka[1].getKolor()){
      gracz1=gracz1+2;}
      
}
cout<< gracz1<<" "<< gracz2<<endl;
};   //zwraca punkty graczy


