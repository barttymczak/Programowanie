#ifndef GRA_H
#define GRA_H

#include "Talia.h"
#include "Karta.h"
#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class Gra{
  private:
    int gracz1;
    int gracz2;
    Talia T1;
    Talia T2;
  public:
    Gra();
    void setup();   //rozdziela talie na pół -> robi 2 stosy
    void rozgrywka();   //zwraca punkty graczy
  };
  
  
#endif
