#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>


#include "Talia.h"
#include "Karta.h"
#include "Gra.h"

using namespace std;

int main() {
    srand(time(NULL));
    Gra gra;
    gra.setup();
    gra.rozgrywka();
    //system("pause"); // Dodane, aby program nie zamykał się od razu po wykonaniu.
    return 0;
}
