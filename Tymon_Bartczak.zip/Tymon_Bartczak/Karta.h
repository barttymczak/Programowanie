#ifndef KARTA_H
#define KARTA_H

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class Karta{
  private:
  int wartosc; //1 do 13
  int kolor; //1 do 4
  public:
  Karta(){};
  Karta(int w, int k);
  void setWartosc(int w);
  double getWartosc() ;
  void setKolor(int k) ;
  double getKolor() ;
 /* bool czyMniejsza(){};
  bool czyZgodnyKolor(){};
  */
  string info();
  };
  
  #endif
