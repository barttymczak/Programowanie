#ifndef TALIA_H
#define TALIA_H

#include <iostream>
#include <string>
#include <cmath>
#include <vector>
#include "Karta.h"

using namespace std;

class Talia{
private:
  vector<Karta> taliaKart;
  string kolorRzedu;
  bool czyZpliku(const Karta& karta) const;
  bool czyPotasowana(const Karta& karta) const;
public:
    Talia();
    Talia(int){};
    void tasuj(){};
    bool czyMoznaDodac(const Karta& karta) const;
    int pobierzLiczbeKart() const;
};

  
  #endif
