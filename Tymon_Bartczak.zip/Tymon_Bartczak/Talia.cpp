#include <iostream>

#include <string>
#include <cmath>
#include "Talia.h"
#include "Karta.h"
using namespace std;

// zrobic metody do talii
/*
Talia::Talia(int w, int k){
  wartosc = w; kolor = k;}
void Karta::setWartosc(int w){ wartosc=w;}
  double Karta::getWartosc(){return wartosc;}
  void Karta::setKolor(int k){ kolor=k;}
  double Karta::getKolor(){return kolor;}
  
  
  string Karta::info(){
    string s;
    s= to_string(wartosc) + " " + to_string(kolor);
  return s;
  }
  

int main(){
    
    Karta k1(1,2);
    Karta k2;
    k2.setWartosc(3);
    k2.setKolor(5);
    k1.setWartosc(1);
    cout<<k2.info()<<endl;


}*/
