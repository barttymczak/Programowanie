#include <iostream>
#include "Talia.h"
#include "Karta.h"







int main(){
    
    Karta k1(1,2);
    Karta k2;
    k2.setWartosc(3);
    k2.setKolor(5);
    k1.setWartosc(1);
    cout<<k2.info()<<endl;


}
