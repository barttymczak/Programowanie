#include <iostream>

#include <string>
#include <cmath>
#include "Karta.h"
using namespace std;

// dodac ograniczenia wartosci i koloru, dodac bool-e
Karta::Karta(int w, int k){
  wartosc = w; kolor = k;}
void Karta::setWartosc(int w){ wartosc=w;}
  double Karta::getWartosc(){return wartosc;}
  void Karta::setKolor(int k){ kolor=k;}
  double Karta::getKolor(){return kolor;}
 /* bool czyMniejsza(){
    if(
  };
  bool czyZgodnyKolor(){
  return (
  };
  */
  string Karta::info(){
    string s;
    s= to_string(wartosc) + " " + to_string(kolor);
  return s;
}
