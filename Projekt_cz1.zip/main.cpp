#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>


#include "Talia.h"
#include "Karta.h"

using namespace std;

int main() {
    srand(time(NULL));

    int losowaWartosc = rand() % 13 + 1;
    int losowyKolor = rand() % 4 + 1;
    Karta losowaKarta(losowaWartosc, losowyKolor);
    cout << "Wylosowana karta na starcie liczbowo: " << losowaKarta.infoLiczbowo() <<" Nazwa:" << losowaKarta.nazwaKarty() << endl;
    // Realizacja kroku 1: Stworzenie losowej karty o wartosci od 1 do 13 oraz kolorze od 1 do 4 i wypisanie 

    char wybor;
    cout << "Czy chcesz stworzyc nowa talie (n) czy wczytac ja z pliku (w)? ";
    cin >> wybor;
    // Realizacja kroku 2: Zapytanie uzytkownika o decyzje dotyczaca przygotowania talii (nowa czy z pliku).

    Talia mojaTalia;
    if (wybor == 'n' || wybor == 'N') {
        mojaTalia = Talia(52, true);
        // Realizacja kroku 3: Stworzenie nowej, pelnej, standardowej talii składającej się z 52 kart.

        mojaTalia.tasuj();
        // Realizacja kroku 4: Jesli stworzono nowa talie, nastepuje jej obowiazkowe potasowanie.

        char czyZapisac;
        cout << "Czy chcesz zapisac te potasowana talie do pliku txt? (t/n): ";
        cin >> czyZapisac;
        // Realizacja kroku 5: Zapytanie uzytkownika, czy chce zapisac swiezo wygenerowany uklad kart do pliku.

        if (czyZapisac == 't' || czyZapisac == 'T') {
            string nazwaPliku;
            cout << "Podaj nazwe pliku (np. talia.txt): ";
            cin >> nazwaPliku;
            mojaTalia.zapiszDoPliku(nazwaPliku);
            // Realizacja kroku 5: Pobranie od uzytkownika nazwy pliku i zapisanie do niego talii kart.
        }
    } else {
        string nazwaPliku;
        cout << "Podaj nazwe pliku tekstowego do wczytania: ";
        cin >> nazwaPliku;
        mojaTalia.wczytajZPliku(nazwaPliku);
        // Realizacja kroku 3: Wczytanie istniejacej struktury talii z pliku tekstowego podanego przez uzytkownika.
    }

    Karta dobranaKarta = mojaTalia.dobierzZWierzchu();

    cout << "Dobrano z wierzchu talii karte: " << dobranaKarta.infoLiczbowo() <<" Nazwa:" << dobranaKarta.nazwaKarty() << endl;
    // Realizacja kroku 6: Dobranie wierzchniej karty, wypisanie informacji (karta znika z zestawu).

    cout << "Zawartosc talii po dobraniu (powinna zawierac 51 kart):" << endl;
    mojaTalia.wypiszTalie();
    // Realizacja kroku 7: Koncowe wypisanie pozostalej zawartosci talii kart do strumienia wyjściowego.
    system("pause"); // Dodane, aby program nie zamykał się od razu po wykonaniu.
    return 0;
}
