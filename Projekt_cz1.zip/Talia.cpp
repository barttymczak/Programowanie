#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>


#include "Talia.h"
#include "Karta.h"
using namespace std;


bool Talia::czyZpliku(const Karta& karta) const {
    return wczytanaZPliku;
}

bool Talia::czyPotasowana(const Karta& karta) const {
    return czyPotasowanaTalia;
}

bool Talia::czyMoznaDodac(const Karta& karta) const {
    if (karta.getWartosc() >= 1 && karta.getWartosc() <= 13 && karta.getKolor() >= 1 && karta.getKolor() <= 4) {
        return true;
    }
    return false;
}

Talia::Talia() {   // konstruktor tworzy pustą talię
    wczytanaZPliku = false;
    czyPotasowanaTalia = false;
}

Talia::Talia(int liczbaKart, bool standardowa) {   // konstruktor tworzy standardową talię 52 lub 24 kart, lub pustą
     wczytanaZPliku = false;
     czyPotasowanaTalia = false;
     if (standardowa && (liczbaKart == 52 || liczbaKart == 24)) {
         int minWartosc = (liczbaKart == 24) ? 9 : 1; 
         for(int k=1; k<=4; k++) {
             for(int w=minWartosc; w<=13; w++) {
                 taliaKart.push_back(Karta(w, k));
             }
         }
     }
 }

 void Talia::tasuj() {   //  tasowanie wektora kart (Talii) - nie tasuje pustej ani wczytanej z pliku
     if (!wczytanaZPliku && !czyPotasowanaTalia && !taliaKart.empty()) {
         random_shuffle(taliaKart.begin(), taliaKart.end());
         czyPotasowanaTalia = true;
     }
 }  

Karta Talia::pobierzKarte(int i) const {   // pobieranie karty z dowolnego miejsca w talii
    if (i >= 0 && i < taliaKart.size()) {
        return taliaKart[i];
    }
    cout << "Blad: Indeks poza zakresem!" << endl;
    return Karta(1, 1);
}

void Talia::ustawKarte(int i, const Karta& k) { // ustawianie karty w dowolnym miejscu w talii
    if (i >= 0 && i < taliaKart.size()) {
        taliaKart[i] = k;
    } else {
        cout << "Blad: Nie mozna ustawic karty, indeks poza zakresem!" << endl;
    }
}

 Karta Talia::dobierzZWierzchu() {   // dobieranie karty z wierzchu talii - nie dobiera z pustej
     if (!taliaKart.empty()) {
         Karta pobrana = taliaKart.back();
         taliaKart.pop_back();
         return pobrana;
     }
     return Karta(-1,-1);   // zwraca blenda karte gdy brak 
 }   



 void Talia::polozNaWierzch(const Karta& k) {   //  kladzenie karty na wierzch ?? po co to ???
     taliaKart.push_back(k);
 }   


void Talia::wypiszTalie() const { // wypisywanie talii - nie wypisuje pustej ani wczytanej z pliku
    if (taliaKart.empty()) {
        cout << "Talia jest pusta." << endl;
       
    }
    for (size_t i = 0; i < taliaKart.size(); i++) {
        Karta k = taliaKart[i];
        cout << k.nazwaKarty() << endl;
    }
}



 void Talia::zapiszDoPliku(string nazwaPliku) const {
    ofstream plik(nazwaPliku);
    if (!plik.is_open()) {
        cout << "Blad: Nie udalo sie otworzyc pliku do zapisu." << endl;
        return;
    }
    for (size_t i = 0; i < taliaKart.size(); i++) {
        Karta k = taliaKart[i];
        plik << k.getWartosc() << " " << k.getKolor() << "\n";
    }
    plik.close();
}   // Zaimplementowano czyszczenie talii i odczyt nowych kart z pliku

void Talia::wczytajZPliku(string nazwaPliku) {
    ifstream plik(nazwaPliku);
    if (!plik.is_open()) {
        cout << "Blad: Nie udalo sie otworzyc pliku do odczytu!" << endl;
        return;
    }
    taliaKart.clear();
    int w, k;
    while (plik >> w >> k) {
        taliaKart.push_back(Karta(w, k));
    }
    plik.close();
    wczytanaZPliku = true;
    czyPotasowanaTalia = false;
}
