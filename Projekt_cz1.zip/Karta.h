#ifndef KARTA_H
#define KARTA_H

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class Karta{
  private:
  int wartosc; //1 do 13
  int kolor; //1 do 4
  public:
  Karta(){};
  Karta(int w, int k);
  void setWartosc(int w);
  int getWartosc() const;
  void setKolor(int k) ;
  int getKolor() const;
  bool czyMniejsza(const Karta& innaKarta) const;
  bool czyTenSamKolor(const Karta& innaKarta) const;
  string nazwaKarty() const;
  string infoLiczbowo() const;
  };
  
  #endif
