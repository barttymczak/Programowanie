#ifndef TALIA_H
#define TALIA_H

#include <iostream>
#include <string>
#include <cmath>
#include <vector>
#include "Karta.h"

using namespace std;

class Talia{
private:
  vector<Karta> taliaKart;
  string kolorRzedu;
  bool wczytanaZPliku;  
  bool czyPotasowanaTalia;
  bool czyZpliku(const Karta& karta) const;
  bool czyPotasowana(const Karta& karta) const;
public:
    Talia();
    Talia(int liczbaKart, bool standardowa);
    void tasuj();
    bool czyMoznaDodac(const Karta& karta) const;
    int pobierzLiczbeKart() const;
    Karta pobierzKarte(int i) const;
    void ustawKarte(int i, const Karta& k);
    Karta dobierzZWierzchu();
    void polozNaWierzch(const Karta& k);
    void zapiszDoPliku(string nazwaPliku) const;
    void wczytajZPliku(string nazwaPliku);
    void wypiszTalie() const;
};

  
  #endif
