#include <iostream>
#include <string>
#include <cmath>
#include "Karta.h"
using namespace std;

// dodac ograniczenia wartosci i koloru, dodac bool-e
Karta::Karta(int w, int k){
  wartosc = w; kolor = k;}
void Karta::setWartosc(int w){ wartosc=w;}
  int Karta::getWartosc()const{return wartosc;}
  void Karta::setKolor(int k){ kolor=k;}
  int Karta::getKolor()const{return kolor;}
  bool Karta::czyMniejsza(const Karta& innaKarta) const { return wartosc < innaKarta.wartosc; }
  bool Karta::czyTenSamKolor(const Karta& innaKarta) const { return kolor == innaKarta.kolor; }
  string Karta::nazwaKarty() const {         // zwraca nazwe karty, np. "As Pik"
       string wartosci[] = {"", "As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Walet", "Dama", "Krol"};
       string kolory[] = {"", "Pik", "Kier", "Trefl", "Karo"};
       if(wartosc >= 1 && wartosc <= 13 && kolor >= 1 && kolor <= 4) return wartosci[wartosc] + "-" + kolory[kolor];
       return "Karta nie istnieje";
   }
  string Karta::infoLiczbowo() const {               // zwraca wartosc i kolor jako liczby
    string s;
    s= to_string(wartosc) + " " + to_string(kolor);
  return s;
  }

